<?php
//wap彩版 配置文件
define("WAP_PAGESIZE", 10);
define("WAP_CPPAGESIZE", 15);
function _get_wap_title($name) {
    $wap_page_title = array(
        'index_about'=>'关于我们',
        'index_contact'=>'联系我们',
        'index_payment'=>'付款方式',
        'index_clause'=>'用户条款',
        'passport_reg'=>'会员注册',
        'passport_profile'=>'完善资料',
        'passport_login'=>'会员登录',
        'idsearch'=>'ID搜索',
        'advsearch'=>'条件搜索',

        'cp_index'=>'会员中心',
        'cp_money'=>'消费记录',
        'cp_listen'=>'我的关注',
        'cp_fans'=>'我的粉丝',
        'cp_visit'=>'我看了谁',
        'cp_visitme'=>'谁看了我',
        'cp_photo'=>'我的相册',
        'cp_message'=>'收信箱',
        'cp_outmsg'=>'发信箱',
        'cp_inhi'=>'收到招呼',
        'cp_outhi'=>'已发招呼',
        'cp_info'=>'修改资料',
        'cp_cond'=>'征友条件',
        'cp_match'=>'缘分速配',
        'cp_buy'=>'购买特权',
        'cp_writemsg'=>'写信件',
        'cp_recharge'=>'在线充值',

        'weibo_list'=>'微心情',
        'party_list'=>'活动列表',
        'party_detail'=>'活动详情',
        'myparty'=>'我报名的活动',
        'pay_show'=>'支付结果',
    );
    return $wap_page_title[$name];
}
?>
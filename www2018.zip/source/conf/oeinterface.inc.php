<?php
define('OEINTERFACE_FLAG', '0');
define('OEINTERFACE_KEY', 'ede9a32940f3dd6140392abbd354960a');
define('OEINTERFACE_URL', '');
define('OEINTERFACE_SYNDEL', '');
define('OEINTERFACE_NAME', '婚嫁网');
?>
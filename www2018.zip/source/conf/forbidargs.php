<?php
define('OE_FORBIDARGS', '操蛋,你妈的,曹大爷');
?>
<?php
define('OECREDIT_FLAG', '0');
define('OECREDIT_KEY', '');
?>
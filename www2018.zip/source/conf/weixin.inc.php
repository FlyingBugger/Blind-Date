<?php
define('WEIXIN_TOKEN', '');
define('WEIXIN_APPID', '');
define('WEIXIN_APPKEY', '');
define('WEIXIN_MCHID', '');
define('WEIXIN_PAYKEY', '');
define('WEIXIN_PAYRATE', '0');
define('WEIXIN_LOGIN_APPID', '');
define('WEIXIN_LOGIN_KEY', '');
?>
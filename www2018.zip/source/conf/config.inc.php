<?php
/**
 * Copyright (C) OELOVE Co.,Ltd. All rights reserved.
 * <E-Mail：service@phpcoo.com>
 * Url http://www.phpcoo.com/
 *     http://www.oelove.com/
**/
///设置时区
define('OESOFT_TIMEZONE', 'Asia/Shanghai');
///系统安装目录
define('OESOFT_ROOT', '/');
///系统Cookies前缀
define('OESOFT_COOKIEPRE', 'x00mbz3m');
///系统编码
define('OESOFT_CHARSET', 'utf-8');
///自定义链接路径
define('PATH_URL', '/');
///前台默认模版目录 不需要填写tpl目录
define('__TPLDIR__', 'default');
///后台默认模版目录 不需要填写tpl目录
define('__ADMIN_TPLDIR__', 'admincp');
///后台管理文件
define('__ADMIN_FILE__', 'admincp.php');
///系统随机码
define('OESOFT_RANDKEY', 'rmkqgzrk5g591ula');
///设置文件体积大小
define('OESOFT_MEMORY_LIMIT', '128M');
///其他设置
define('OESOFT_STYPE', '0');
///安装标识
define('OELOVE', true);
?>
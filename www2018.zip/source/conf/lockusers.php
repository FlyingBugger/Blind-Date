<?php
define('OE_LOCKUSERS', 'admin,administrator,管理员');
?>
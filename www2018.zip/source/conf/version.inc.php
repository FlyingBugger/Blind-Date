<?php
/**
 * [OElove] (C)2012-2099 OEdev,Inc.
 * <E-Mail:phpcoo@qq.com>
 * Url www.phpcoo.com, www.oelove.com
 * Update 2017.12.07
 */
define('OESOFT_SOFTNAME', 'OElove');
define('OESOFT_TYPE', 'Free');
define('OESOFT_VERSION', 'v4.6');
define('OESOFT_RELEASE', ".R71208");
define('OESOFT_LICENCE', 'http://www.phpcoo.com/serial/');
define('OESOFT_URL', 'http://www.phpcoo.com/');
define('OESOFT_AUTHOR', 'OEdev');
?>
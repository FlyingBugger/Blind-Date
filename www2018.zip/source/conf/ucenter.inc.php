<?php
define('OE_UC_FLAG', false);
define('UC_CONNECT', 'mysql');
define('UC_DBHOST', 'localhost:3306');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'root');
define('UC_DBNAME', 'dx');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', 'pre');
define('UC_DBCONNECT', '0');
define('UC_KEY', 'c10cd7LaG55ygUEMQxjsXBkxJutqw6lBnSr4Ew0');
define('UC_API', 'http://dx.a.com/uc_server');
define('UC_CHARSET', 'utf-8');
define('UC_IP', '');
define('UC_APPID', '2');
define('UC_PPP', '20');
?>
<?php
/**
 * Copyright (C) OELOVE Co.,Ltd. All rights reserved.
 * <E-Mail：service@phpcoo.com>
 * Url http://www.phpcoo.com/
 *     http://www.oelove.com/
**/
///数据库类型
define('DB_TYPE', 'mysql');
///数据库编码
define('DB_CHARSET', 'utf8');
///数据库服务器
define('DB_HOST', 'localhost:3306');
///数据库名
define('DB_DATA', 'ftp122778453my');
///数据库登录帐号
define('DB_USER', 'ftp122778453my');
///数据库登录密码
define('DB_PASS', 'E8411E7');
///数据表前缀
define('DB_PREFIX', 'oepre_');
///数据库持久连接 0=关闭, 1=打开
define('DB_PCONNECT', 0);
?>
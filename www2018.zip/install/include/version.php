<?php
define('OE_VERSION', 'v4.6');
define('OE_EDITION', 'Free');
define('OE_PHPVER', '5.2');
?>